module.exports = function (grunt) {
    // Project configuration.
    grunt.initConfig({
    });
};
